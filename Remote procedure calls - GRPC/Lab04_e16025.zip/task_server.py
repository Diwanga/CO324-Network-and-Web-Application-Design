import logging
from concurrent.futures import ThreadPoolExecutor
from grpc import server
import task_pb2, task_pb2_grpc



class TaskapiImpl:
    """'Implementation of the Taskapi service"""
    
    def __init__(self):
        # TODO: initialise attributes to store our tasks.
        self.tasks = task_pb2.Tasks()
     

    def addTask(self, request, context):
        logging.info(f"adding task {request.description}")
        # TODO: implement this!      
        index = len(self.tasks.tasks)
        self.tasks.tasks.append(task_pb2.Task(id=index,description=request.description))
        return task_pb2.Id(id=index)

    def delTask(self, request, context):
        logging.info(f"deleting task {request.id}")
        # TODO: implement this!
        for task in self.tasks.tasks:
            if request.id == task.id:
                self.tasks.tasks.remove(task)
                return task_pb2.Task(id=task.id,description=task.description)



    def listTasks(self, request, context):
        logging.info("returning task list")
        # TODO: implement this!
        return self.tasks


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    with ThreadPoolExecutor(max_workers=1) as pool:
        taskserver = server(pool)
        task_pb2_grpc.add_TaskapiServicer_to_server(TaskapiImpl(), taskserver)
        taskserver.add_insecure_port("[::]:50051")
        try:
            taskserver.start()
            logging.info("Taskapi ready to serve requests")
            taskserver.wait_for_termination()
        except:
            logging.info("Shutting down server")
            taskserver.stop(None)
